package com.bluebik.car.musclecar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.bluebik.car.musclecar.DAOImp.MuscleCarServiceImp;
import com.bluebik.car.musclecar.Model.MuscleCarModel;

import java.util.List;
import java.util.Map;

/**
 * Copyright © 2016 Bluebik Group.
 * Created by khakhanat on 24/10/2017 AD.
 */
@RestController
@RequestMapping(value = "/api/cars")
public class MuscleCarController {

    private MuscleCarServiceImp muscleCarService;

    @Autowired
    public MuscleCarController(MuscleCarServiceImp muscleCarService) {
        this.muscleCarService = muscleCarService;
    }

    @RequestMapping(value = "/get-car", method = RequestMethod.GET)
    public ResponseEntity<MuscleCarModel> getMuscleCar(int id) {

        try {
            MuscleCarModel muscleCar = muscleCarService.getCar(id);
            if (muscleCar != null) {
                return ResponseEntity.status(HttpStatus.OK).body(muscleCar);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

    }

    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ResponseEntity<Void> deleteMuscleCar(int id) {

        try {
            muscleCarService.removeCarFromList(id);
            return ResponseEntity.status(HttpStatus.OK).build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<Void> addCarToList(MuscleCarModel muscleCar) {

        try {
            muscleCarService.addCarToList(muscleCar);
            return ResponseEntity.status(HttpStatus.OK).build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @RequestMapping(value = "/cars", method = RequestMethod.GET)
    public ResponseEntity<List<Map<String, Object>>> listAllCars() {

        try {
            List<Map<String, Object>> result = muscleCarService.listAllCars();
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseEntity<Void> updateCar(MuscleCarModel muscleCar) {

        try {
        	int id=0;
            muscleCarService.updateCarFromList(id, muscleCar);
            return ResponseEntity.status(HttpStatus.OK).build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
    @RequestMapping("")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}

}
