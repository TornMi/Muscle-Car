package com.bluebik.car.musclecar.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.bluebik.car.musclecar.Model.MuscleCarModel; 
public class MuscleCarRowMapper implements RowMapper<MuscleCarModel> {
   @Override
   public MuscleCarModel mapRow(ResultSet row, int rowNum) throws SQLException {
	MuscleCarModel muscleCar = new MuscleCarModel();
	muscleCar.setCarId(row.getString("car_id"));
	muscleCar.setCarBrand(row.getString("brands"));
	muscleCar.setCarModel(row.getString("model"));
	muscleCar.setCarEngine(row.getString("engine"));
	muscleCar.setHorsepower(row.getString("horse_power"));
	//muscleCar.set(row.getString("category"));
	return muscleCar;
   }
}