package com.bluebik.car.musclecar.DAOImp;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

//import javax.annotation.PostConstruct;
//import javax.sql.DataSource;

//import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.bluebik.car.musclecar.DAO.MuscleCarDao;
import com.bluebik.car.musclecar.Mapper.MuscleCarRowMapper;
import com.bluebik.car.musclecar.Model.MuscleCarModel;


/**
 * Copyright © 2016 Bluebik Group.
 * Created by khakhanat on 24/10/2017 AD.
 */
@Repository
public class MuscleCarDaoImpl implements MuscleCarDao {

	@Autowired
    private JdbcTemplate jdbcTemplate;
    
    public MuscleCarDaoImpl() {
    }

    @Override
    public MuscleCarModel getCarFromList(int id) {
    	List<MuscleCarModel> result = new ArrayList<MuscleCarModel>();
    	Map<String,Object> map=new HashMap<String,Object>();
    	String sql = "SELECT * FROM cars where car_id="+id;
    	RowMapper<MuscleCarModel> rowMapper = new MuscleCarRowMapper();
    	result=this.jdbcTemplate.query(sql, rowMapper);
       return result.size()>0?this.jdbcTemplate.query(sql, rowMapper).get(0):null;
       
    }

    @Override
    public void removeCarFromList(int id) {
    	try {
    		String sql = "DELETE FROM cars where car_id="+id;
        	this.jdbcTemplate.update(sql);
    	}catch(Exception e) {
    		
    	}
    	
    }

    @Override
    public void addCarToList(MuscleCarModel muscleCar) {
    	String sql1 = "select max(car_id) maxId FROM cars";
    
    	List<Integer> maxIdList=this.jdbcTemplate.query(sql1,new RowMapper<Integer>() {
			@Override
			public Integer mapRow(ResultSet rs,int rowNum) throws SQLException {
				int maxId = rs.getInt("maxId");
				return maxId;
			}
		});
       int maxId= maxIdList.size()>0?maxIdList.get(0):0;
       String maxidStr = ""+(maxId+1);
       String sql="INSERT INTO cars VALUES ('"+maxidStr+"','"+muscleCar.getCarBrand()+"','"+muscleCar.getCarModel()+"', '"+muscleCar.getCarEngine()+"','"+muscleCar.getHorsepower()+"')";
    		   this.jdbcTemplate.update(sql);
    }

    @Override
    public void updateCarFromList(MuscleCarModel muscleCar) {
    	String sql = "UPDATE cars SET brands='"+muscleCar.getCarBrand()+"', model='"+muscleCar.getCarModel()+"',\n" + 
    			"engine='"+muscleCar.getCarEngine()+"', horse_power='"+muscleCar.getHorsepower()+"' WHERE car_id="+muscleCar.getCarId();
    	this.jdbcTemplate.update(sql);

    }

    @Override
    public List<Map<String, Object>> listAllCars() {
    	List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
    	Map<String,Object> map=new HashMap<String,Object>();
    	
    	String sql = "SELECT * FROM cars";
    	RowMapper<MuscleCarModel> rowMapper = new MuscleCarRowMapper();
    	map.put("MuscleCars", this.jdbcTemplate.query(sql, rowMapper));
    	result.add(map);
    	
		return result;
    }

}
