package com.bluebik.car.musclecar;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Copyright © 2016 Bluebik Group.
 * Created by khakhanat on 24/10/2017 AD.
 */
public class MuscleCarDaoImpl implements MuscleCarDao {

    public MuscleCarDaoImpl() {
    }

    @Override
    public MuscleCar getCarFromList(int id) {
        return new MuscleCar("1", "2", "3", "4");
    }

    @Override
    public void removeCarFromList(int id) {

    }

    @Override
    public void addCarToList(MuscleCar muscleCar) {

    }

    @Override
    public void updateCarFromList(int id, MuscleCar muscleCar) {

    }

    @Override
    public List<Map<String, Object>> listAllCars() {
        return new ArrayList<>();
    }

}
