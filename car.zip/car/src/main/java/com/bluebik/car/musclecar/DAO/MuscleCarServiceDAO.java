package com.bluebik.car.musclecar.DAO;

import java.util.List;
import java.util.Map;

import com.bluebik.car.musclecar.Model.MuscleCarModel;

public interface MuscleCarServiceDAO {
	 public MuscleCarModel getCar(int id);

	    public void removeCarFromList(int id);

	    public List<Map<String, Object>> listAllCars();
	    public void addCarToList(MuscleCarModel muscleCar) ;

	    public void updateCarFromList(int id, MuscleCarModel muscleCar);
}
