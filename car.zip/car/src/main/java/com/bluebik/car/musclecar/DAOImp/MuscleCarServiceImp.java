package com.bluebik.car.musclecar.DAOImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluebik.car.musclecar.DAO.MuscleCarDao;
import com.bluebik.car.musclecar.DAO.MuscleCarServiceDAO;
import com.bluebik.car.musclecar.Model.MuscleCarModel;

import java.util.List;
import java.util.Map;

/**
 * Copyright © 2016 Bluebik Group.
 * Created by khakhanat on 24/10/2017 AD.
 */
@Service
public class MuscleCarServiceImp  implements MuscleCarServiceDAO{
	@Autowired
    private MuscleCarDao muscleCarDao;
	
	@Override
    public MuscleCarModel getCar(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID can not be 0 or <0");
        }
        return muscleCarDao.getCarFromList(id);
    }
	@Override
    public void removeCarFromList(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID can not be 0 or <0 or this id do not exist");
        }
        muscleCarDao.removeCarFromList(id);
    }
	@Override
    public List<Map<String, Object>> listAllCars() {

        List<Map<String, Object>> result = muscleCarDao.listAllCars();
        if (result.size() > 0) {
            return result;
        } else {
            return null;
        }
    }
	@Override
    public void addCarToList(MuscleCarModel muscleCar) {
        if (muscleCar == null) {
            throw new IllegalArgumentException("The passed object cna not be null.");
        }
        muscleCarDao.addCarToList(muscleCar);
    }
	@Override
    public void updateCarFromList(int id, MuscleCarModel muscleCar) {
        if (id <= 0 && muscleCar == null) {
            throw new IllegalArgumentException("The passed object cna not be null.");
        }
        muscleCarDao.updateCarFromList(muscleCar);
    }

}
