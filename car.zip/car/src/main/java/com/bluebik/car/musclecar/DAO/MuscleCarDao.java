package com.bluebik.car.musclecar.DAO;

import java.util.List;
import java.util.Map;

import com.bluebik.car.musclecar.Model.MuscleCarModel;

/**
 * Copyright © 2016 Bluebik Group.
 * Created by khakhanat on 24/10/2017 AD.
 */
public interface MuscleCarDao {

    public MuscleCarModel getCarFromList(int id);

    public void removeCarFromList(int id);

    public void addCarToList(MuscleCarModel muscleCar);

    public void updateCarFromList(MuscleCarModel muscleCar);

    public List<Map<String, Object>> listAllCars();

}
