var flag =true;
var id='';
$(document).ready(function(){
			getData();
			$("#bth-search").click(function() {
				getData();
			});
});

function getData(){
	var form = $("#search-form");
	$('.resultSearch').empty();
	$.get('cars', function(muscleCars) {
		
			var toAppend = '';
			console.log("muscleCars "+muscleCars);
			toAppend += '<table class="" style="width: 100%;">';
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">')
			toAppend+=(' <col width="20%">')
			toAppend += '<thead >';
			toAppend += '	<tr >';
			toAppend += '		<th>Car Id</th>';
			toAppend += '		<th>Brand</th>';
			toAppend += '		<th>Model</th>';
			toAppend += '		<th>Horse Power</th>';
			toAppend += '		<th>Engine</th>';
			toAppend += '		<th></th>';
			toAppend += '	</tr >';
			toAppend += '</thead >';
			toAppend += '<tbody >';
			toAppend += '</tbody>';
			toAppend += '</table>';
			toAppend += ' <div class="scrollit">';
			toAppend += ' <table  class="table table-hover ">';
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">');
			toAppend+=(' <col width="16%">')
			toAppend+=(' <col width="20%">')

			
			$.each(muscleCars[0].MuscleCars,function(index, data) {
				console.log("index "+index);
				toAppend += '<tr>';
					toAppend += '<td>'+ data.carId+ '</td>';
					toAppend += '<td>'+ data.carBrand+ '</td>';
					toAppend += '<td>'+ data.carModel+ '</td>';
					toAppend += '<td>'+ data.horsepower+ '</td>';
					toAppend += '<td>'+ data.carEngine+ '</td>';
					toAppend += '<td>';
					toAppend += '<button onclick="carsManage(false,\''+ data.carId + '\');" class="btn btn-warning"  type="button" style=" margin: 4px;">Edit</button>';
					toAppend += '<button onclick="carsDelete(\''+ data.carId + '\');"  class="btn btn-danger"  type="button">Delete</button>';
					toAppend += '</td>';
					toAppend += '</tr>';

		});
			toAppend += ' 				</table>';
		$('.resultSearch').html(toAppend);
	});
	
	
}
function carsManage(isCreate,carId){
	flag=true;
	if(isCreate){
		$( "#brand" ).val('');
		$( "#model" ).val('');
		$( "#horsePower" ).val('');
		$( "#engine" ).val('');
		$('#myModal').modal('show');
	}
	else{
		flag=false;
		id=carId;
		$.get('get-car',{id: carId}, function(muscleCars) {
			$( "#brand" ).val(muscleCars.carBrand);
			$( "#model" ).val(muscleCars.carModel);
			$( "#horsePower" ).val(muscleCars.horsepower);
			$( "#engine" ).val(muscleCars.carEngine);
			$('#myModal').modal('show');
			

		});
	}

}
function carsDelete(carId){
	
	$.get('delete',{id: carId}, function(muscleCars) {
		getData();
	});
	
}
function carAdd(){

	if(flag){
		var formData = {
				carId : '',
				carBrand :  $("#brand").val(),
				carModel : $("#model").val(),
				horsepower :  $("#horsePower").val(),
				carEngine :  $("#engine").val()
			}
    	
		$.post('add',formData, function(muscleCars) {
			getData();
			
		});
	}
	else{
		var formData = {
				carId : id,
				carBrand :  $("#brand").val(),
				carModel : $("#model").val(),
				horsepower :  $("#horsePower").val(),
				carEngine :  $("#engine").val()
			}
		$.post('update',formData, function(muscleCars) {
			getData();
			
		});
	}

	

}
	